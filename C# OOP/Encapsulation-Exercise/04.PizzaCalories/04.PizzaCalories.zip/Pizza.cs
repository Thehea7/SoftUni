﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace _04.PizzaCalories
{
    public class Pizza
    {
        private readonly string name;
        private Dough dough;
        private List<Topping> toppings;


        public Pizza(string name)
        {
            Name = name;
            toppings = new List<Topping>();
        }
        public Pizza(string name, Dough dough, List<Topping> toppings)
        {
            Name = name;
            this.dough = dough;
            Toppings = toppings;
        }

        public Dough Dough
        {
            get => dough;
            set => dough = value;
        }


        public void AddTopping(Topping topping)
        {
            if (ToppingsCount < 10)
                Toppings.Add(topping);
            else
            {
                throw new ArgumentException("Number of toppings should be in range [0..10].");
            }
        }
        public decimal Calories
        {
            get
            {
                decimal result = dough.Calories;
                Toppings.ForEach(x => result += x.Calories);
                return result;
            }
        }

        public int ToppingsCount => toppings.Count;
        private List<Topping> Toppings
        {
            get => toppings;
            init
            {
                if (value.Count > 10)
                {
                    throw new ArgumentException("Number of toppings should be in range [0..10].");
                }
                toppings = value;
            }
        }



        public string Name
        {
            get => name;
            init
            {
                if (string.IsNullOrWhiteSpace(value)
                    || value.Length > 15)
                {
                    throw new ArgumentException("Pizza name should be between 1 and 15 symbols.");
                }
                name = value;
            }


        }

    }
}
