﻿

using _01.Vehicles.Core;
using _01.Vehicles.Core.Models;
using _01.Vehicles.Factories;
using _01.Vehicles.Factories.Interfaces;
using _01.Vehicles.IO;
using _01.Vehicles.IO.Interfaces;

namespace _01.Vehicles
{
    public class StartUp
    {
        static void Main()
        {
            RunSolution1();
            //RunSolution2();
        }

        private static void RunSolution1()
        {
            IReader reader = new ConsoleReader();
            IWriter writer = new ConsoleWriter();
            // IWriter writer = new FileWriter();  // Use this "writer" to write result in File
            IVehicleFactory vehicleFactory = new VehicleFactory();
            IEngine engine = new Engine(reader, writer, vehicleFactory);
            engine.Run();
        }
        private static void RunSolution2()
        {
            IReader reader = new ConsoleReader();
            IWriter writer = new ConsoleWriter();
            // IWriter writer = new FileWriter(); // Use this "writer" to write result in File

            IVehicleFactory vehicleFactory = new VehicleFactory_02();

            IEngine engine = new Engine_02(reader, writer, vehicleFactory);

            engine.Run();
        }
    }
}
