﻿namespace _04_WildFarm.Models.Food
{
    public class Fruit : Food
    {
        public Fruit(int food) : base(food)
        {
        }
    }
}
