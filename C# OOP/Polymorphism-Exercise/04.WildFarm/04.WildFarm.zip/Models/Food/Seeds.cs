﻿namespace _04_WildFarm.Models.Food
{
    public class Seeds : Food 
    {
        public Seeds(int food) : base(food)
        {
        }
    }
}
