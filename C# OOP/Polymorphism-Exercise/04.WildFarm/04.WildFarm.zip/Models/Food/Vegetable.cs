﻿namespace _04_WildFarm.Models.Food
{
    public class Vegetable : Food
    {
        public Vegetable(int food) : base(food)
        {
        }
    }
}
