﻿namespace _04_WildFarm.Models.Food.Interfaces
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
