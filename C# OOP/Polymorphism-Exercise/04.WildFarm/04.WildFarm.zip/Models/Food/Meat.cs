﻿namespace _04_WildFarm.Models.Food
{
    public class Meat : Food
    {
        public Meat(int food) : base(food)
        {
        }
    }
}
