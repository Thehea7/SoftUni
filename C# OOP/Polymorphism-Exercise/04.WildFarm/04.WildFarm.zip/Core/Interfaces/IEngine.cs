﻿namespace _04_WildFarm.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
