﻿namespace _04_WildFarm.IO.Interfaces
{
    public interface IWriter
    {
        void WriteLine(object obj);

        void Write(object obj);
    }
}
