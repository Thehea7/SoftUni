﻿namespace _04_WildFarm.IO.Interfaces
{
    public interface IReader
    {
        string Readline();

    }
}
