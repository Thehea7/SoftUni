﻿

namespace _03_Raiding.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();

    }
}
