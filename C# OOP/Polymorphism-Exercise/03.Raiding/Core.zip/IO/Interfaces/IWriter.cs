﻿namespace _03_Raiding.IO.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string str);

        void Write(string str);
    }
}
