﻿namespace _03_Raiding.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
