﻿using _04.BorderControl.Core;
using _04.BorderControl.Core.Interfaces;

IEngine engine = new Engine();
engine.Run();