﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04.BorderControl.Models
{
    public class Citizen : Entity
    {
        public Citizen(string name, string id) : base(name, id)
        {
        }
    }
}
