﻿using _07.MilitaryElite.Core;
using _07.MilitaryElite.Core.Interfaces;

IEngine engine = new Engine();
engine.Run();