﻿
namespace _07.MilitaryElite.Models.Interfaces
{
    public interface ISoldier 
    {
        string Id { get; init; }
        string FirstName { get; init; }
        string LastName { get; init; }
    }
}
