﻿using _08.CollectionHierarchy.Core;
using _08.CollectionHierarchy.Core.Interfaces;

IEngine engine = new Engine();
engine.Run();