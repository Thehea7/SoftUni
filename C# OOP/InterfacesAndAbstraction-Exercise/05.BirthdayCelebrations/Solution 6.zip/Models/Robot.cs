﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.BirthdayCelebrations.Models
{
    public class Robot : Entity
    {
        public Robot(string name, string id) : base(name, id)
        {
        }
    }
}
