﻿
using _05.BirthdayCelebrations;
using _05.BirthdayCelebrations.Core.Core;

//IEngine engine = new Engine();
IEngine engine = new EngineForproblem_06();
engine.Run();
