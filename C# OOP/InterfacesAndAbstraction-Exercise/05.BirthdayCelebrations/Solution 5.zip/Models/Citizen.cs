﻿

using _05.BirthdayCelebrations.Models.Interfaces;

namespace _05.BirthdayCelebrations
{
    public class Citizen : Entity, IBorn
    {
        public int Age { get; set; }
        public string Birthday { get; init; }
        public Citizen(string name, string id,int age, string birthday) : base(name, id)
        {
            Birthday = birthday;
            Age = age;
        }
    }
}
