﻿
using _05.BirthdayCelebrations;

IEngine engine = new Engine();
engine.Run();
