﻿

namespace _09.ExplicitInterfaces.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
