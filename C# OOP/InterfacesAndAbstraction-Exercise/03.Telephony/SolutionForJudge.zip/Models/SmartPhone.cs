﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.Telephony
{
    public  class SmartPhone : ICallable, IBrowse
    {
        public void Call(string number)
        {
            if (number.All(char.IsNumber))
            {
                if (number.Length == 10)
                {
                    Console.WriteLine($"Calling... {number}");
                }
            }
            else
            {
                throw new ArgumentException("Invalid number!");
            }

            
        }


        public void Browse(string url)
        {
            char a = url.FirstOrDefault(x => char.IsNumber(x));
            
            if (url.Any(char.IsNumber))
            {
                throw new ArgumentException("Invalid URL!");
            }
            Console.WriteLine($"Browsing: {url}!");
        }
    }
}
