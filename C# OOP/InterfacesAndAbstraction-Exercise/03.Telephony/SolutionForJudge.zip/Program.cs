﻿using _03.Telephony;

string[] phoneNumbers = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
string[] urls = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

List<ICallable> callers  = new List<ICallable>();

SmartPhone smarthphone = new SmartPhone();
ICallable Stationary  = new StationaryPhone();


callers.Add(smarthphone); callers.Add(Stationary);


foreach (var phoneNumber in phoneNumbers)
{
    try
    {
        callers.ForEach(x => x.Call(phoneNumber));
    }
    catch (ArgumentException e)
    {
        Console.WriteLine(e.Message);
    }
    
}

foreach (var url in urls)
{
    try
    {
        smarthphone.Browse(url);
    }
    catch (ArgumentException e)
    {
        Console.WriteLine(e.Message);
    }
    
}



