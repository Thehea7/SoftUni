﻿using System;
using System.Collections.Generic;
using System.Threading.Channels;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            List<Hero> list = new List<Hero>();
            list.Add(new Hero("WynterWyvern", 30));
            list.Add(new BladeKnight("WynterWyvern", 30));
            list.Add(new DarkKnight("WynterWyvern", 30));
            list.Add(new DarkWizard("WynterWyvern", 30));
            list.Add(new Elf("WynterWyvern", 30));
            list.Add(new Knight("WynterWyvern", 30));
            list.Add(new MuseElf("WynterWyvern", 30));
            list.Add(new SoulMaster("WynterWyvern", 30));

            list.ForEach(x => Console.WriteLine(x));
        }
    }
}