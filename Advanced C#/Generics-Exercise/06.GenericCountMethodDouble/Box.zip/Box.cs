﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.GenericBoxOfString
{
    internal class Box<T>
    {
        public T Item { get; set; }

        public Box(T item)
        {
            Item = item;
        }

        public static void Swap<T>(List<T> list, int index1, int index2)
        {
            (list[index1] , list[index2]) = (list[index2] ,list[index1]);
        }

        public static int CountGreaterElements<T>(List<Box<T>> list, T element) where T : IComparable
        {
            int count = 0;

            foreach (var item in list)
            {
                if (item.Item.CompareTo(element) == 1)
                {
                    count++;
                }
            }

            return count;
        }
        public override string ToString()
        {
            return $"{typeof(T)}: {Item}";
        }
    }
}
