﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07.CustomComparator
{
    public class Comparator : IComparer<int>
    {
        private int number;

        public int IsOdd(int x, int y)
        {
            if (x % 2 == 0 && y % 2 == 0)
            {
                return 0;
            }

            if (x % 2 == 0 && y % 2 != 0)
            {
                return -1;
            }
            else
            {
                return 1;
            }
        }

        public int Compare(int x, int y)
        {
            int result = IsOdd(x, y);
            if (result == 0)
            {
                return x.CompareTo(y);
            }
            return result;
        }
    }
}
