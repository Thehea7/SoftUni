﻿using _07.CustomComparator;

IComparer<int> comparer = new Comparator();

int[] array = Console.ReadLine()
    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
    .Select(int.Parse)
    .ToArray();


    Array.Sort(array, comparer);

Console.WriteLine(string.Join(" ", array));