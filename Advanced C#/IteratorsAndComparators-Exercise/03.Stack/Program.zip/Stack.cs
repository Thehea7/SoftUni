﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.Stack
{
    public class Stack<T> : IEnumerable<T>
    {
        public Node<T> Tail { get; set; }

        public void Push(params T[] items)
        {
            foreach (var item in items)
            {
                if (Tail == null)
                {
                    Tail = new Node<T>();
                    Tail.Value = item;
                    continue;
                }

                Node<T> current = new Node<T>();
                current.Value = item;
                current.Previous = Tail;
                Tail = current;
            }
            
        }

        public T Pop()
        {
            if (Tail == null)
            {
                throw new InvalidOperationException();
            }
            T output = Tail.Value;
            Tail = Tail.Previous;

            return output;
        }

        public IEnumerator<T> GetEnumerator()
        {
            Node<T> currentNode = new Node<T>();
            currentNode = Tail;
            while (currentNode != null)
            {
                yield return currentNode.Value;
                currentNode = currentNode.Previous;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
