﻿

using _03.Stack;

NodeSolution();




void NodeSolution()
{
    _03.Stack.Stack<int> myStack = new _03.Stack.Stack<int>();


    string[] arguments = Console.ReadLine().Split(new[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);



    myStack.Push(arguments.Select(int.Parse).ToArray());

    
    //if (myStack.Any())
    //{
    //    Console.Write(string.Join(", ", myStack.Where(x => x.IsOdd).OrderBy(x => x.index)));
    //    if (myStack.Tail.index > 0)
    //    {
    //        Console.Write($", ");
    //    }
    //    Console.WriteLine(string.Join(", ", myStack.Where(x => x.IsOdd == false).OrderByDescending(x => x.index)));
    //}
    Console.WriteLine(string.Join(", ", myStack));
}

