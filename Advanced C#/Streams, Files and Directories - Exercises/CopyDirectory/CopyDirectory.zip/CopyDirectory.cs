﻿using System.IO;

namespace CopyDirectory
{
    using System;
    public class CopyDirectory
    {
        static void Main()
        {
            //string inputPath =  @$"{Console.ReadLine()}";
            string inputPath = @$"C:\Users\a.matsev\OneDrive - DraftKings\GitHub\SoftUni\Advanced C#\Streams, Files and Directories - Exercises\test\New folder";

            // string outputPath = @$"{Console.ReadLine()}";
            string outputPath = @$"C:\Users\a.matsev\OneDrive - DraftKings\GitHub\SoftUni\Advanced C#\Streams, Files and Directories - Exercises\test\New folder (2)";

            CopyAllFiles(inputPath, outputPath);
        }

        public static void CopyAllFiles(string inputPath, string outputPath)
        {
            if (Directory.Exists(outputPath))
            {
                Directory.Delete(outputPath, true);
            }

            Directory.CreateDirectory(outputPath);

            string[] files = Directory.GetFiles(inputPath);

            foreach (string file in files)
            {
                
                FileInfo info = new FileInfo(file);

                Console.WriteLine(info.Name);
                //string destination = Path.Combine(outputPath, info.Name)
                File.Copy(file, $"{outputPath}\\{info.Name}");

                //string fileLocation = $"{inputPath}\\{info.Name}";
               // Directory.Move(fileLocation, outputPath);
            }
        }
                
    }
}
