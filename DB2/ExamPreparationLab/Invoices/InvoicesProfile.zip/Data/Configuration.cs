﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            "Server=DESKTOP-IKUABEV\\SQLSOFTUNI;Database=Invoices2024;Trusted_Connection=True;TrustServerCertificate=True";
    }
}
