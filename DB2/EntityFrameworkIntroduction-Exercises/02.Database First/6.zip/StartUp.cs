﻿using System.Net;
using System.Net.Http.Headers;
using System.Text;
using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using SoftUni.Models;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main()
        {
            SoftUniContext context = new ();


            //Console.WriteLine(GetEmployeesFullInformation(context));  //// 3.	Employees Full Information

            //Console.WriteLine(GetEmployeesWithSalaryOver50000(context)); // 4.	Employees with Salary Over 50 000

            //Console.WriteLine(GetEmployeesFromResearchAndDevelopment(context)); //05. Employees from Research and Development

            Console.WriteLine(AddNewAddressToEmployee(context));

        }

       
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            ////Option 1
            //return string.Join(Environment.NewLine, context.Employees
            //    .Select(e => $"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:f2}")
            //    .ToList());

            //Option 2
            var employees = context.Employees
                .Select(e => new
                {
                    e.EmployeeId,
                    e.FirstName,
                    e.LastName,
                    e.MiddleName,
                    e.JobTitle,
                    e.Salary
                })
                .OrderBy(e => e.EmployeeId)
                .ToList();

            StringBuilder sb = new();
            foreach (var e in employees)
            {
                sb.AppendLine($"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:f2}");
            }
            return sb.ToString().Trim();
        } // 3.	Employees Full Information

        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            var richEmployees = context.Employees
                .Where(e => e.Salary > 50000)
                .Select(e => new
                {
                    e.FirstName,
                    e.Salary
                })
                .OrderBy(e => e.FirstName);

            StringBuilder sb = new();

            foreach (var e in richEmployees)
            {
                sb.AppendLine($"{e.FirstName} - {e.Salary:f2}");
            }

            return sb.ToString().Trim();
        } //4.	Employees with Salary Over 50 000


        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context) // 05. Employees from Research and Development
        {


            var employees = context.Employees
                .Where(e => e.Department.Name == "Research and Development")
                .Select(e => new
                {
                    e.FirstName,
                    e.LastName,
                    departmentName = e.Department.Name,
                    e.Salary
                })
                .OrderBy(e => e.Salary)
                .ThenByDescending(e => e.FirstName);
           // Console.WriteLine(employees.ToQueryString());

            StringBuilder sb = new();
            foreach (var e in employees)
            {
                 sb.AppendLine($"{e.FirstName} {e.LastName} from {e.departmentName} - ${e.Salary:f2}");
            }

            return sb.ToString().Trim();
        }

        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            Address address = new Address();
            address.AddressText = "Vitoshka 15";
            address.TownId = 4;

            Employee nakov = context.Employees
                .FirstOrDefault(e => e.LastName == "Nakov");

            if (nakov != null)
            {
                nakov.Address = address;
            }

            context.SaveChanges();

            var employees = context.Employees
                .Select(e => new
                {
                    adresText = e.Address.AddressText,
                    id = e.AddressId
                })
                .OrderByDescending(e => e.id)
                .Take(10);

            StringBuilder sb = new();

            foreach (var e in employees)
            {
                sb.AppendLine(e.adresText);
            }

            return sb.ToString().Trim();
        } //06. Adding a New Address and Updating Employee
    }
}
