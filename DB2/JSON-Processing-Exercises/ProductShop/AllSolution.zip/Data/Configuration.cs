﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            "Server=DESKTOP-IKUABEV\\SQLSOFTUNI;Database=ProductShop;Trusted_Connection=True;TrustServerCertificate=True";
    }
}
